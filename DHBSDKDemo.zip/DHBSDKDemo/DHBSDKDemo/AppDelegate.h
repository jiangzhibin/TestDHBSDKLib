//
//  AppDelegate.h
//  DHBSDKDemo
//
//  Created by 蒋兵兵 on 16/8/17.
//  Copyright © 2016年 yulore. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

